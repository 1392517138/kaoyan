create view user_base as
  select
    `kaoyan`.`user`.`userId`         AS `userId`,
    `kaoyan`.`user`.`userName`       AS `userName`,
    `kaoyan`.`user`.`userIdCard`     AS `userIdCard`,
    `kaoyan`.`user`.`sex`            AS `sex`,
    `kaoyan`.`user`.`telephone`      AS `telephone`,
    `kaoyan`.`user`.`eamil`          AS `eamil`,
    `kaoyan`.`user`.`birth`          AS `birth`,
    `kaoyan`.`user`.`password`       AS `password`,
    `kaoyan`.`role`.`roleName`       AS `roleName`,
    `kaoyan`.`major`.`majorName`     AS `majorName`,
    `kaoyan`.`college`.`collegeName` AS `collegeName`
  from `kaoyan`.`user`
    join `kaoyan`.`role`
    join `kaoyan`.`major`
    join `kaoyan`.`college`
  where
    ((`kaoyan`.`user`.`roleId` = `kaoyan`.`role`.`roleId`) and (`kaoyan`.`user`.`majorId` = `kaoyan`.`major`.`majorId`)
     and (`kaoyan`.`user`.`collegeId` = `kaoyan`.`college`.`collegeId`));

